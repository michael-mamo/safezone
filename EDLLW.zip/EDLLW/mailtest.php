<?php
mail('derejewudu@gmail.com', 'test subject', 'hello Dera','FROM: redaitth@gmail.com')
?>