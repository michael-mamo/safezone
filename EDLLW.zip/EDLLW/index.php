<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/jemari.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	
</head>
<body>
	<div class="wrapper ">
		<div class="nav Section_top">
			<div class="logo contentn">
			 <a style="text-decoration: none;color: #fff; " href="index.php">መንጃ ፍቃድ መማርያ</a>
		</div>
		<div class="menu">
			<ul>
				<li><a href="index.php">መነሻ ገጽ</a></li>
				<li><a href="About-us.php">ስለእኛ</a></li>
				<li><a href="contact-us">ያግኙን</a></li>
				<li><a href="Login.php" style="color: yellow;">መግቢያ</a></li>
				<li><a href="Tutorial.php">መማርያ</a></li>
			</ul>
		</div>
	</div>	
	<div class="header">
		<h1> መንጃ ፍቃድ መማርያ</h1>
		  <p> አደጋን በጋራ እንከላከል
		  </p>
		 <button type="button"><a style="text-decoration: none;color: #fff; " href="Tutorial.php">መማርያ</a> </button>

		 
	</div>



</div>

</body>




</body>
</html>