<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Home</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" type="text/css" href="css/jemari.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.css">
	
</head>
<body>
	<div class="wrapper">
		<div class="nav">
			<div class="logo">
			 <a style="text-decoration: none;color: #fff; " href="index.php">መንጃ ፍቃድ መማርያ</a>
		</div>
		<div class="menu">
			<ul>
				<li><a href="index.php">መነሻ ገጽ</a></li>
				<li><a href="About-us.php">ስለእኛ</a></li>
				<li><a href="contact-us.php">ያግኙን</a></li>
				<li><a href="Login.php" style="color: yellow;">መግቢያ</a></li>
				<li><a href="Tutorial.php">መማርያ</a></li>
			</ul>
		</div>
	</div>	
	<div class="header">
		
		<h3>Developer</h3>
<div class="deve">
	<ul>
		<li><div style="color: #fff; display: inline-block;">
			<h4>Kaleab </h4><i>kaleb@gmail.com</i><br><br><i style="color: #fafafa"> +2512992933</i>
		</div>
	</li>
	</ul>
	</div>	 
	</div>



</div>

</body>




</body>
</html>